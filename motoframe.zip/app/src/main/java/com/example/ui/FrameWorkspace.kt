package com.example.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.data.FrameDesign
import com.example.data.FrameNode
import com.example.ui.theme.*
import kotlin.math.sqrt
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FrameWorkspace(viewModel: FrameViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Observe state from ViewModel
    val currentNodes by viewModel.currentNodes.collectAsStateWithLifecycle()
    val motorType by viewModel.motorType.collectAsStateWithLifecycle()
    val designName by viewModel.designName.collectAsStateWithLifecycle()
    val wheelbaseMm by viewModel.wheelbaseMm.collectAsStateWithLifecycle()
    val materialType by viewModel.materialType.collectAsStateWithLifecycle()
    val tubeOD by viewModel.tubeOD.collectAsStateWithLifecycle()
    val tubeThickness by viewModel.tubeThickness.collectAsStateWithLifecycle()
    val backgroundType by viewModel.backgroundType.collectAsStateWithLifecycle()
    val customPhotoUri by viewModel.customPhotoUri.collectAsStateWithLifecycle()
    val aiAnalysis by viewModel.aiAnalysis.collectAsStateWithLifecycle()
    val isLoadingAi by viewModel.isLoadingAi.collectAsStateWithLifecycle()
    val savedDesigns by viewModel.savedDesigns.collectAsStateWithLifecycle()
    val activeDesignId by viewModel.activeDesignId.collectAsStateWithLifecycle()

    // Calculated Specs in real-time
    val metrics = viewModel.getCalculatedMetrics()

    // Screen tabs (to fit everything beautifully in a single view)
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Tracer & Kanvas", "Spesifikasi & Pipa", "Analisis AI", "Galeri Desain")

    // Image Picker for custom tracing photo
    val photoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.setCustomPhotoUri(uri.toString())
        }
    }

    var showSaveDialog by remember { mutableStateOf(false) }
    var saveNameInput by remember { mutableStateOf("") }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.DirectionsBike,
                            contentDescription = "Logo",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Column {
                            Text(
                                text = "MotoFrame",
                                fontWeight = FontWeight.Black,
                                fontSize = 20.sp,
                                color = MaterialTheme.colorScheme.onBackground,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Chassis CAD & AI Assistant",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }
                    }
                },
                actions = {
                    // Quick Preset Indicator
                    SuggestionChip(
                        onClick = { },
                        label = { Text("Kategori: $motorType", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                        modifier = Modifier.padding(end = 8.dp),
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Real-time quick HUD metrics bar
            MetricsStatusBar(metrics = metrics, wheelbaseMm = wheelbaseMm)

            // Dynamic interactive canvas (Takes 40% height on typical mobile portrait)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(
                        width = 2.dp,
                        color = MaterialTheme.colorScheme.outline,
                        shape = RoundedCornerShape(28.dp)
                    )
            ) {
                InteractiveCanvas(
                    nodes = currentNodes,
                    segments = viewModel.segments,
                    backgroundType = backgroundType,
                    customPhotoUri = customPhotoUri,
                    metrics = metrics,
                    viewModel = viewModel
                )

                // Tracing Opacity Guide Overlay / Mode Selector
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(12.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f), RoundedCornerShape(16.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Latar:", fontSize = 10.sp, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold)
                    Text(
                        text = "Cetak Biru",
                        color = if (backgroundType == "blueprint") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable { viewModel.setBackgroundType("blueprint") }
                            .testTag("bg_blueprint_button")
                    )
                    Text(
                        text = "Foto",
                        color = if (backgroundType == "gallery") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable {
                                if (customPhotoUri == null) {
                                    photoLauncher.launch("image/*")
                                } else {
                                    viewModel.setBackgroundType("gallery")
                                }
                            }
                            .testTag("bg_photo_button")
                    )
                    Text(
                        text = "Grid Polos",
                        color = if (backgroundType == "grid") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable { viewModel.setBackgroundType("grid") }
                            .testTag("bg_grid_button")
                    )
                    if (customPhotoUri != null) {
                        IconButton(
                            onClick = { photoLauncher.launch("image/*") },
                            modifier = Modifier.size(16.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Ubah foto",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }

                // Help overlay
                Text(
                    text = "Geser titik untuk mengubah geometri sasis motor",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                )
            }

            // Material Tab selector
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 12.sp,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == index) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary
                            )
                        }
                    )
                }
            }

            // Tab contents
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(16.dp)
            ) {
                when (selectedTab) {
                    0 -> TracingTab(
                        motorType = motorType,
                        designName = designName,
                        onPresetSelected = { viewModel.loadPreset(it) },
                        onSaveClick = {
                            saveNameInput = designName
                            showSaveDialog = true
                        },
                        activeDesignId = activeDesignId,
                        onNewDesign = { viewModel.loadPreset(motorType) }
                    )
                    1 -> SpecsTab(
                        wheelbaseMm = wheelbaseMm,
                        onWheelbaseChanged = { viewModel.setWheelbase(it) },
                        materialType = materialType,
                        onMaterialChanged = { viewModel.setMaterialType(it) },
                        tubeOD = tubeOD,
                        onTubeODChanged = { viewModel.setTubeOD(it) },
                        tubeThickness = tubeThickness,
                        onTubeThicknessChanged = { viewModel.setTubeThickness(it) },
                        metrics = metrics
                    )
                    2 -> AiAnalysisTab(
                        aiAnalysis = aiAnalysis,
                        isLoadingAi = isLoadingAi,
                        onRunAnalysis = { viewModel.runAiAnalysis() }
                    )
                    3 -> GalleryTab(
                        savedDesigns = savedDesigns,
                        activeId = activeDesignId,
                        onLoad = { viewModel.loadDesign(it) },
                        onDelete = { viewModel.deleteDesign(it) }
                    )
                }
            }
        }
    }

    // Save Design Dialog
    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Simpan Desain Sasis", color = Color.White) },
            text = {
                Column {
                    Text("Beri nama untuk konfigurasi ukuran sasis ini:", color = SteelGrey, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = saveNameInput,
                        onValueChange = { saveNameInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("save_name_input"),
                        textStyle = LocalTextStyle.current.copy(color = MaterialTheme.colorScheme.onSurface),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        ),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setDesignName(saveNameInput)
                        viewModel.saveCurrentDesign()
                        showSaveDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier.testTag("dialog_confirm_save_button")
                ) {
                    Text("Simpan")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("Batal", color = MaterialTheme.colorScheme.tertiary)
                }
            },
            containerColor = MaterialTheme.colorScheme.surface
        )
    }
}

@Composable
fun MetricsStatusBar(metrics: FrameMetrics, wheelbaseMm: Float) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val stats = listOf(
            Triple("Sumbu Roda", "${wheelbaseMm.toInt()} mm", MaterialTheme.colorScheme.onBackground),
            Triple("Sudut Rake", "${String.format("%.1f", metrics.rakeAngle)}°", MaterialTheme.colorScheme.primary),
            Triple("Jarak Trail", "${metrics.trailMm.toInt()} mm", GeoTextDeepAccent),
            Triple("Tinggi Jok", "${metrics.seatHeightMm.toInt()} mm", MaterialTheme.colorScheme.onBackground)
        )

        stats.forEach { (label, value, valueColor) ->
            Card(
                modifier = Modifier
                    .weight(1f),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp, horizontal = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = label,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.tertiary,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = value,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = valueColor,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun InteractiveCanvas(
    nodes: List<FrameNode>,
    segments: List<FrameSegment>,
    backgroundType: String,
    customPhotoUri: String?,
    metrics: FrameMetrics,
    viewModel: FrameViewModel
) {
    var canvasWidthPx by remember { mutableStateOf(0) }
    var canvasHeightPx by remember { mutableStateOf(0) }
    var activeDraggingNodeId by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .onSizeChanged {
                canvasWidthPx = it.width
                canvasHeightPx = it.height
            }
            .pointerInput(nodes) {
                detectDragGestures(
                    onDragStart = { offset ->
                        val thresholdPx = 32.dp.toPx()
                        val closestNode = nodes.minByOrNull { node ->
                            val px = node.x * canvasWidthPx
                            val py = node.y * canvasHeightPx
                            val dx = offset.x - px
                            val dy = offset.y - py
                            sqrt(dx * dx + dy * dy)
                        }
                        if (closestNode != null) {
                            val px = closestNode.x * canvasWidthPx
                            val py = closestNode.y * canvasHeightPx
                            val dist = sqrt((offset.x - px) * (offset.x - px) + (offset.y - py) * (offset.y - py))
                            if (dist <= thresholdPx) {
                                activeDraggingNodeId = closestNode.id
                            }
                        }
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val draggingId = activeDraggingNodeId
                        if (draggingId != null && canvasWidthPx > 0 && canvasHeightPx > 0) {
                            val currentNode = nodes.find { it.id == draggingId }
                            if (currentNode != null) {
                                val newX = (currentNode.x + dragAmount.x / canvasWidthPx).coerceIn(0.01f, 0.99f)
                                val newY = (currentNode.y + dragAmount.y / canvasHeightPx).coerceIn(0.01f, 0.99f)
                                viewModel.updateNodePosition(draggingId, newX, newY)
                            }
                        }
                    },
                    onDragEnd = { activeDraggingNodeId = null },
                    onDragCancel = { activeDraggingNodeId = null }
                )
            }
    ) {
        // 1. Draw Background Trace Image
        when (backgroundType) {
            "blueprint" -> {
                Image(
                    painter = painterResource(id = R.drawable.img_motor_blueprint),
                    contentDescription = "Motor Blueprint Schematic",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit,
                    alpha = 0.55f
                )
            }
            "gallery" -> {
                if (customPhotoUri != null) {
                    AsyncImage(
                        model = customPhotoUri,
                        contentDescription = "Custom Motor Tracing Photo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit,
                        alpha = 0.6f
                    )
                } else {
                    // Fallback to blueprint if null
                    Image(
                        painter = painterResource(id = R.drawable.img_motor_blueprint),
                        contentDescription = "Motor Blueprint Schematic",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit,
                        alpha = 0.55f
                    )
                }
            }
            "grid" -> {
                // Draws pure grid background via custom Canvas drawBehind
            }
        }

        // 2. Main CAD Drawing Canvas for pipes and intersections
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .drawBehind {
                    // Draw Blueprint grid overlay if requested or for blueprint look
                    val gridSpacing = 40.dp.toPx()
                    val width = size.width
                    val height = size.height

                    // Grid color: subtle purple border
                    val gridColor = GeoBorder.copy(alpha = if (backgroundType == "grid") 0.4f else 0.15f)

                    for (x in 0..(width / gridSpacing).toInt()) {
                        drawLine(
                            color = gridColor,
                            start = Offset(x * gridSpacing, 0f),
                            end = Offset(x * gridSpacing, height),
                            strokeWidth = 1f
                        )
                    }
                    for (y in 0..(height / gridSpacing).toInt()) {
                        drawLine(
                            color = gridColor,
                            start = Offset(0f, y * gridSpacing),
                            end = Offset(width, y * gridSpacing),
                            strokeWidth = 1f
                        )
                    }

                    // Draw ground line approximation
                    val rHubNode = nodes.find { it.id == "rear_hub" }
                    if (rHubNode != null) {
                        val scale = metrics.scale
                        val groundY = (rHubNode.y * height) + (300f / scale)
                        drawLine(
                            color = GeoBorder,
                            start = Offset(0f, groundY),
                            end = Offset(width, groundY),
                            strokeWidth = 2f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                        )
                    }
                }
        ) {
            if (canvasWidthPx == 0 || canvasHeightPx == 0) return@Canvas

            // A. Draw Tube Segments (Pipes)
            segments.forEach { seg ->
                val n1 = nodes.find { it.id == seg.fromId }
                val n2 = nodes.find { it.id == seg.toId }
                if (n1 != null && n2 != null) {
                    val p1 = Offset(n1.x * size.width, n1.y * size.height)
                    val p2 = Offset(n2.x * size.width, n2.y * size.height)

                    if (seg.isStructural) {
                        // Drawing thick tubular metallic structure
                        // Outer glowing border
                        drawLine(
                            color = GeoSecondary.copy(alpha = 0.4f),
                            start = p1,
                            end = p2,
                            strokeWidth = 18f,
                            cap = androidx.compose.ui.graphics.StrokeCap.Round
                        )
                        // Inner structural pipe core
                        drawLine(
                            color = GeoPrimary,
                            start = p1,
                            end = p2,
                            strokeWidth = 6f,
                            cap = androidx.compose.ui.graphics.StrokeCap.Round
                        )
                    } else {
                        // Non-structural lines (e.g. Fork axis, Shock absorber)
                        val color = when (seg.id) {
                            "fork_axis" -> GeoTertiary.copy(alpha = 0.6f)
                            "rear_shock" -> GeoTextDeepAccent
                            "swingarm" -> GeoTertiary
                            else -> GeoTertiary
                        }
                        val pathEffect = if (seg.id == "fork_axis") {
                            PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
                        } else null

                        drawLine(
                            color = color,
                            start = p1,
                            end = p2,
                            strokeWidth = if (seg.id == "swingarm") 8f else 4f,
                            cap = androidx.compose.ui.graphics.StrokeCap.Round,
                            pathEffect = pathEffect
                        )
                    }
                }
            }

            // B. Draw Interactive Nodes / Joints
            nodes.forEach { node ->
                val center = Offset(node.x * size.width, node.y * size.height)
                val isDragging = node.id == activeDraggingNodeId

                // Hub vs Chassis Joint visual different
                val isHub = node.id == "front_hub" || node.id == "rear_hub"

                if (isDragging) {
                    // Interactive Pulsing Drag Halo
                    drawCircle(
                        color = GeoSecondary.copy(alpha = 0.6f),
                        radius = 22.dp.toPx(),
                        center = center
                    )
                }

                // Node background glow circle
                drawCircle(
                    color = if (isHub) GeoTextDeepAccent.copy(alpha = 0.2f) else GeoPrimary.copy(alpha = 0.2f),
                    radius = 12.dp.toPx(),
                    center = center
                )

                // Outer border line
                drawCircle(
                    color = if (isHub) GeoTextDeepAccent else GeoPrimary,
                    radius = 7.dp.toPx(),
                    center = center,
                    style = Stroke(width = 2.dp.toPx())
                )

                // Solid center pin core
                drawCircle(
                    color = if (isDragging) GeoTextDeepAccent else Color.White,
                    radius = 3.dp.toPx(),
                    center = center
                )
            }
        }

        // 3. Floating Node Labels Overlay (drawn as Compose views to stay high-quality and crisp)
        nodes.forEach { node ->
            val isDragging = node.id == activeDraggingNodeId
            val isHub = node.id == "front_hub" || node.id == "rear_hub"
            
            Box(
                modifier = Modifier
                    .offset(
                        x = (node.x * canvasWidthPx / LocalContext.current.resources.displayMetrics.density).dp - 40.dp,
                        y = (node.y * canvasHeightPx / LocalContext.current.resources.displayMetrics.density).dp + 10.dp
                    )
                    .width(80.dp)
            ) {
                Text(
                    text = node.label.substringBefore(" ("),
                    color = if (isDragging) GeoTextDeepAccent else if (isHub) GeoTertiary else GeoTextDark,
                    fontSize = 8.sp,
                    fontWeight = if (isDragging) FontWeight.Bold else FontWeight.Normal,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun TracingTab(
    motorType: String,
    designName: String,
    onPresetSelected: (String) -> Unit,
    onSaveClick: () -> Unit,
    activeDesignId: Long?,
    onNewDesign: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Workspace status
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Nama Konfigurasi", fontSize = 11.sp, color = MaterialTheme.colorScheme.tertiary)
                        Text(
                            text = designName,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    if (activeDesignId != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                "Tersimpan (ID: $activeDesignId)",
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Surface(
                            color = GeoTextDeepAccent.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                "Draf Baru",
                                color = GeoTextDeepAccent,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Preset Selections
        Text(
            text = "Pilih Template Cetak Rangka",
            color = MaterialTheme.colorScheme.onBackground,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val presets = listOf(
                "Sport" to Icons.Default.SportsMotorsports,
                "Chopper" to Icons.Default.CompassCalibration,
                "Underbone" to Icons.Default.PedalBike,
                "CafeRacer" to Icons.Default.ElectricBike
            )

            presets.forEach { (type, icon) ->
                val isSelected = motorType == type
                Button(
                    onClick = { onPresetSelected(type) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                        contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                    ),
                    border = BorderStroke(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
                    modifier = Modifier
                        .weight(1f)
                        .height(64.dp)
                        .testTag("preset_${type.lowercase()}_button"),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(4.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(imageVector = icon, contentDescription = type, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = when (type) {
                                "Sport" -> "Sport"
                                "Chopper" -> "Chopper"
                                "Underbone" -> "Bebek"
                                else -> "Cafe Racer"
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Save & Edit Action buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onNewDesign,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("new_design_button"),
                shape = RoundedCornerShape(24.dp)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "New")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Reset / Baru", fontSize = 13.sp)
            }

            Button(
                onClick = onSaveClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("save_design_button"),
                shape = RoundedCornerShape(24.dp)
            ) {
                Icon(imageVector = Icons.Default.Save, contentDescription = "Save")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Simpan Sasis", fontSize = 13.sp)
            }
        }

        // Quick Tutorial info card
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Tips",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Tips: Hubungkan ponsel Anda ke internet lalu buka tab 'Analisis AI' untuk mendapatkan tinjauan struktur kekuatan sasis motor Anda dari kecerdasan buatan.",
                    color = MaterialTheme.colorScheme.tertiary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
fun SpecsTab(
    wheelbaseMm: Float,
    onWheelbaseChanged: (Float) -> Unit,
    materialType: String,
    onMaterialChanged: (String) -> Unit,
    tubeOD: Float,
    onTubeODChanged: (Float) -> Unit,
    tubeThickness: Float,
    onTubeThicknessChanged: (Float) -> Unit,
    metrics: FrameMetrics
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Kalibrasi & Jarak Sumbu Roda", color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Jarak Sumbu Roda (Wheelbase)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                    Text("${wheelbaseMm.toInt()} mm", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                Slider(
                    value = wheelbaseMm,
                    onValueChange = onWheelbaseChanged,
                    valueRange = 1000f..2000f,
                    colors = SliderDefaults.colors(
                        activeTrackColor = MaterialTheme.colorScheme.primary,
                        thumbColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("wheelbase_slider")
                )
                Text(
                    "Mengatur wheelbase sesungguhnya akan menyelaraskan panjang pipa rangka secara otomatis berdasarkan rasio piksel pada foto.",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.tertiary,
                    lineHeight = 14.sp
                )
            }
        }

        Text("Bahan Baku & Spesifikasi Pipa Sasis", color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold, fontSize = 14.sp)

        // Material Selector Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val materials = listOf("Seamless Steel (Baja)", "Chromoly (4130)", "Aluminium")
            materials.forEach { mat ->
                val isSelected = materialType == mat
                Surface(
                    color = if (isSelected) MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1.0f)
                        .clickable { onMaterialChanged(mat) }
                        .testTag("mat_${mat.split(" ")[0].lowercase()}_button")
                ) {
                    Box(modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = mat.substringBefore(" ("),
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                // Tube OD
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Diameter Luar Pipa (OD)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text("${String.format("%.1f", tubeOD)} mm", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Slider(
                        value = tubeOD,
                        onValueChange = onTubeODChanged,
                        valueRange = 19f..38f,
                        colors = SliderDefaults.colors(activeTrackColor = MaterialTheme.colorScheme.primary, thumbColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.testTag("tube_od_slider")
                    )
                }

                // Tube Wall Thickness
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Ketebalan Dinding Pipa", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text("${String.format("%.1f", tubeThickness)} mm", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Slider(
                        value = tubeThickness,
                        onValueChange = onTubeThicknessChanged,
                        valueRange = 1.2f..3.5f,
                        colors = SliderDefaults.colors(activeTrackColor = MaterialTheme.colorScheme.primary, thumbColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.testTag("tube_thickness_slider")
                    )
                }
            }
        }

        // Estimasi Berat Rangka
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Estimasi Berat Sasis", fontSize = 12.sp, color = MaterialTheme.colorScheme.tertiary)
                    Text(
                        text = "Hanya Pipa Struktural Utama",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
                Text(
                    text = "${String.format("%.2f", metrics.frameWeightKg)} kg",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = GeoTextDeepAccent,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun AiAnalysisTab(
    aiAnalysis: String?,
    isLoadingAi: Boolean,
    onRunAnalysis: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Tinjauan Teknis AI (Gemini)",
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )

            Button(
                onClick = onRunAnalysis,
                enabled = !isLoadingAi,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    disabledContainerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .height(38.dp)
                    .testTag("run_ai_analysis_button")
            ) {
                if (isLoadingAi) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    Icon(imageVector = Icons.Default.Psychology, contentDescription = "AI", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Mulai Analisis", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Analysis Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp))
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            if (aiAnalysis != null) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState)
                ) {
                    Text(
                        text = aiAnalysis,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "AI Waiting",
                        tint = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.5f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Silakan klik tombol 'Mulai Analisis' di atas.\nGemini AI akan meninjau kekuatan material, sudut stabilitas kemudi, dan pusat gravitasi sasis motor Anda.",
                        color = MaterialTheme.colorScheme.tertiary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun GalleryTab(
    savedDesigns: List<FrameDesign>,
    activeId: Long?,
    onLoad: (FrameDesign) -> Unit,
    onDelete: (FrameDesign) -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Desain Sasis Tersimpan", color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold, fontSize = 14.sp)

        if (savedDesigns.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.FolderOpen,
                    contentDescription = "Empty",
                    tint = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.4f),
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text("Belum ada sasis yang disimpan", color = MaterialTheme.colorScheme.tertiary, fontSize = 12.sp)
                Text("Rancang sasis motor Anda, lalu ketuk 'Simpan Sasis'", color = MaterialTheme.colorScheme.tertiary, fontSize = 11.sp)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                savedDesigns.forEach { design ->
                    val isActive = design.id == activeId
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isActive) MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable { onLoad(design) }
                            .testTag("saved_design_${design.id}"),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = design.name,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            design.motorType,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Text(
                                        text = "${design.wheelbaseMm.toInt()}mm | Rake ${String.format("%.1f", design.rakeAngle)}°",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (isActive) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Active",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(end = 8.dp)
                                    )
                                }
                                IconButton(
                                    onClick = { onDelete(design) },
                                    modifier = Modifier.testTag("delete_design_${design.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Hapus",
                                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
