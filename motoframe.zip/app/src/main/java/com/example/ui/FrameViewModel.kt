package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.GeminiClient
import com.example.data.AppDatabase
import com.example.data.FrameDesign
import com.example.data.FrameNode
import com.example.data.FrameRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class FrameViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: FrameRepository
    val savedDesigns: StateFlow<List<FrameDesign>>

    init {
        val database = AppDatabase.getDatabase(application)
        repository = FrameRepository(database.frameDesignDao())
        savedDesigns = repository.allDesigns.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    // Interactive UI States
    private val _currentNodes = MutableStateFlow<List<FrameNode>>(emptyList())
    val currentNodes: StateFlow<List<FrameNode>> = _currentNodes.asStateFlow()

    private val _motorType = MutableStateFlow("Sport") // Sport, Chopper, Underbone, CafeRacer, Custom
    val motorType: StateFlow<String> = _motorType.asStateFlow()

    private val _designName = MutableStateFlow("Desain Sasis Sport #1")
    val designName: StateFlow<String> = _designName.asStateFlow()

    private val _wheelbaseMm = MutableStateFlow(1300f)
    val wheelbaseMm: StateFlow<Float> = _wheelbaseMm.asStateFlow()

    private val _materialType = MutableStateFlow("Seamless Steel (Baja)") // Seamless Steel, Chromoly, Aluminum, Titanium
    val materialType: StateFlow<String> = _materialType.asStateFlow()

    private val _tubeOD = MutableStateFlow(25.4f) // mm
    val tubeOD: StateFlow<Float> = _tubeOD.asStateFlow()

    private val _tubeThickness = MutableStateFlow(2.0f) // mm
    val tubeThickness: StateFlow<Float> = _tubeThickness.asStateFlow()

    private val _backgroundType = MutableStateFlow("blueprint") // blueprint, grid, gallery
    val backgroundType: StateFlow<String> = _backgroundType.asStateFlow()

    private val _customPhotoUri = MutableStateFlow<String?>(null)
    val customPhotoUri: StateFlow<String?> = _customPhotoUri.asStateFlow()

    private val _aiAnalysis = MutableStateFlow<String?>(null)
    val aiAnalysis: StateFlow<String?> = _aiAnalysis.asStateFlow()

    private val _isLoadingAi = MutableStateFlow(false)
    val isLoadingAi: StateFlow<Boolean> = _isLoadingAi.asStateFlow()

    private val _activeDesignId = MutableStateFlow<Long?>(null)
    val activeDesignId: StateFlow<Long?> = _activeDesignId.asStateFlow()

    init {
        // Load default preset
        loadPreset("Sport")
    }

    // Segments configuration
    val segments = listOf(
        // Fork line (non-structural, drawn dashed for rake geometry)
        FrameSegment("fork_axis", "steering_head", "front_hub", "Garpu Depan", isStructural = false),
        // Backbone & Top structure
        FrameSegment("backbone", "steering_head", "backbone_joint", "Backbone Sasis", isStructural = true),
        FrameSegment("top_tube", "backbone_joint", "seat_front", "Pipa Utama Atas", isStructural = true),
        // Subframe
        FrameSegment("seat_rail", "seat_front", "seat_rear", "Subframe Jok", isStructural = true),
        FrameSegment("subframe_brace", "seat_rear", "swingarm_pivot", "Penyangga Jok Diagonal", isStructural = true),
        FrameSegment("center_post", "seat_front", "swingarm_pivot", "Tiang Tengah (Seat Tube)", isStructural = true),
        // Bottom cradle / Down tube
        FrameSegment("down_tube", "steering_head", "engine_front", "Down Tube", isStructural = true),
        FrameSegment("bottom_cradle", "engine_front", "engine_rear", "Dudukan Mesin Bawah", isStructural = true),
        FrameSegment("rear_brace", "engine_rear", "swingarm_pivot", "Penyangga Poros Ayun", isStructural = true),
        // Swingarm (non-structural frame weight, but structural for chassis)
        FrameSegment("swingarm", "swingarm_pivot", "rear_hub", "Lengan Ayun (Swingarm)", isStructural = false),
        // Shock
        FrameSegment("rear_shock", "rear_hub", "seat_front", "Shockbreaker Belakang", isStructural = false)
    )

    fun setBackgroundType(type: String) {
        _backgroundType.value = type
    }

    fun setCustomPhotoUri(uri: String?) {
        _customPhotoUri.value = uri
        if (uri != null) {
            _backgroundType.value = "gallery"
        }
    }

    fun setDesignName(name: String) {
        _designName.value = name
    }

    fun setWheelbase(value: Float) {
        _wheelbaseMm.value = value.coerceIn(900f, 2200f)
    }

    fun setMaterialType(material: String) {
        _materialType.value = material
    }

    fun setTubeOD(od: Float) {
        _tubeOD.value = od.coerceIn(12f, 50f)
    }

    fun setTubeThickness(t: Float) {
        _tubeThickness.value = t.coerceIn(1f, 5f)
    }

    fun updateNodePosition(id: String, x: Float, y: Float) {
        _currentNodes.value = _currentNodes.value.map { node ->
            if (node.id == id) {
                node.copy(x = x.coerceIn(0.01f, 0.99f), y = y.coerceIn(0.01f, 0.99f))
            } else {
                node
            }
        }
    }

    // Geometry Calculation getters
    fun getCalculatedMetrics(): FrameMetrics {
        val nodes = _currentNodes.value
        val fHub = nodes.find { it.id == "front_hub" } ?: return FrameMetrics()
        val rHub = nodes.find { it.id == "rear_hub" } ?: return FrameMetrics()
        val stHead = nodes.find { it.id == "steering_head" } ?: return FrameMetrics()
        val seatF = nodes.find { it.id == "seat_front" } ?: return FrameMetrics()

        // Horiz & vert distance between hubs in scale
        val dxHubs = fHub.x - rHub.x
        val dyHubs = fHub.y - rHub.y
        val pixelWheelbase = sqrt(dxHubs * dxHubs + dyHubs * dyHubs)

        if (pixelWheelbase < 0.01f) return FrameMetrics()

        val scaleMmPerPixel = _wheelbaseMm.value / pixelWheelbase

        // 1. Rake Angle (Steering Head to Front Hub vector angle relative to Vertical)
        val dxFork = fHub.x - stHead.x
        val dyFork = fHub.y - stHead.y
        val rakeRad = atan2(abs(dxFork), abs(dyFork))
        val rakeDeg = Math.toDegrees(rakeRad.toDouble()).toFloat()

        // 2. Trail (Approx chassis formula based on 17-inch wheel (radius 300mm) and 35mm offset)
        val wheelRadiusMm = 300f
        val tripleClampOffsetMm = 35f
        val rakeRadDouble = rakeRad.toDouble()
        val trailMm = if (cos(rakeRadDouble) > 0.05) {
            ((wheelRadiusMm * sin(rakeRadDouble) - tripleClampOffsetMm) / cos(rakeRadDouble)).toFloat()
        } else {
            0f
        }

        // 3. Seat Height (Vertical distance from rear wheel bottom to seat_front)
        // Wheel center is at height 300mm. So ground line y coordinate is hub.y + (300 / scaleMmPerPixel)
        val groundY = rHub.y + (300f / scaleMmPerPixel)
        val pixelSeatHeight = groundY - seatF.y
        val seatHeightMm = pixelSeatHeight * scaleMmPerPixel

        // 4. Frame Weight estimation (Sum of structural segments)
        val density = when (_materialType.value) {
            "Aluminium" -> 2.7f // g/cm³
            "Titanium" -> 4.5f
            else -> 7.85f // Chromoly / Steel
        }

        var totalWeightG = 0f
        val od = _tubeOD.value
        val thickness = _tubeThickness.value
        val id = od - 2f * thickness
        val areaMm2 = (Math.PI * (od * od - id * id) / 4.0).toFloat()

        segments.forEach { seg ->
            if (seg.isStructural) {
                val n1 = nodes.find { it.id == seg.fromId }
                val n2 = nodes.find { it.id == seg.toId }
                if (n1 != null && n2 != null) {
                    val dx = n1.x - n2.x
                    val dy = n1.y - n2.y
                    val segPixelLen = sqrt(dx * dx + dy * dy)
                    val segLenMm = segPixelLen * scaleMmPerPixel
                    val volumeMm3 = areaMm2 * segLenMm
                    val volumeCm3 = volumeMm3 / 1000f
                    val weightG = volumeCm3 * density
                    totalWeightG += weightG
                }
            }
        }

        return FrameMetrics(
            rakeAngle = rakeDeg,
            trailMm = trailMm.coerceIn(0f, 250f),
            seatHeightMm = seatHeightMm.coerceIn(200f, 1500f),
            frameWeightKg = totalWeightG / 1000f,
            scale = scaleMmPerPixel
        )
    }

    fun loadPreset(type: String) {
        _motorType.value = type
        val metrics = when (type) {
            "Sport" -> {
                _wheelbaseMm.value = 1350f
                _designName.value = "Desain Sasis Sport #1"
                _tubeOD.value = 28f
                _tubeThickness.value = 2.0f
                listOf(
                    FrameNode("front_hub", "As Roda Depan", 0.15f, 0.75f),
                    FrameNode("steering_head", "Komstir (Steering Head)", 0.35f, 0.32f),
                    FrameNode("backbone_joint", "Pangkal Backbone", 0.48f, 0.34f),
                    FrameNode("engine_front", "Dudukan Mesin Depan", 0.38f, 0.58f),
                    FrameNode("engine_rear", "Dudukan Mesin Belakang", 0.52f, 0.64f),
                    FrameNode("swingarm_pivot", "Poros Lengan Ayun", 0.62f, 0.64f),
                    FrameNode("rear_hub", "As Roda Belakang", 0.85f, 0.75f),
                    FrameNode("seat_front", "Dudukan Jok Depan", 0.58f, 0.42f),
                    FrameNode("seat_rear", "Ujung Jok Belakang", 0.74f, 0.42f)
                )
            }
            "Chopper" -> {
                _wheelbaseMm.value = 1650f
                _designName.value = "Desain Chopper Stretched #1"
                _tubeOD.value = 31.8f
                _tubeThickness.value = 2.5f
                listOf(
                    FrameNode("front_hub", "As Roda Depan", 0.10f, 0.75f),
                    FrameNode("steering_head", "Komstir (Steering Head)", 0.38f, 0.22f), // High and far back
                    FrameNode("backbone_joint", "Pangkal Backbone", 0.48f, 0.36f),
                    FrameNode("engine_front", "Dudukan Mesin Depan", 0.42f, 0.62f),
                    FrameNode("engine_rear", "Dudukan Mesin Belakang", 0.56f, 0.68f),
                    FrameNode("swingarm_pivot", "Poros Lengan Ayun", 0.64f, 0.68f),
                    FrameNode("rear_hub", "As Roda Belakang", 0.90f, 0.75f),
                    FrameNode("seat_front", "Dudukan Jok Depan", 0.60f, 0.52f), // Very low seat
                    FrameNode("seat_rear", "Ujung Jok Belakang", 0.78f, 0.48f)
                )
            }
            "Underbone" -> { // Bebek / Scooter
                _wheelbaseMm.value = 1220f
                _designName.value = "Desain Rangka Bebek #1"
                _tubeOD.value = 25.4f
                _tubeThickness.value = 2.0f
                listOf(
                    FrameNode("front_hub", "As Roda Depan", 0.18f, 0.75f),
                    FrameNode("steering_head", "Komstir (Steering Head)", 0.36f, 0.35f),
                    FrameNode("backbone_joint", "Pangkal Backbone (Low)", 0.44f, 0.60f), // Dropped step-through
                    FrameNode("engine_front", "Dudukan Mesin Depan", 0.44f, 0.68f),
                    FrameNode("engine_rear", "Dudukan Mesin Belakang", 0.55f, 0.66f),
                    FrameNode("swingarm_pivot", "Poros Lengan Ayun", 0.63f, 0.65f),
                    FrameNode("rear_hub", "As Roda Belakang", 0.83f, 0.75f),
                    FrameNode("seat_front", "Dudukan Jok Depan", 0.56f, 0.45f),
                    FrameNode("seat_rear", "Ujung Jok Belakang", 0.72f, 0.45f)
                )
            }
            "CafeRacer" -> {
                _wheelbaseMm.value = 1300f
                _designName.value = "Desain Cafe Racer Flat #1"
                _tubeOD.value = 25.4f
                _tubeThickness.value = 2.0f
                listOf(
                    FrameNode("front_hub", "As Roda Depan", 0.16f, 0.75f),
                    FrameNode("steering_head", "Komstir (Steering Head)", 0.34f, 0.34f),
                    FrameNode("backbone_joint", "Pangkal Backbone", 0.45f, 0.38f),
                    FrameNode("engine_front", "Dudukan Mesin Depan", 0.37f, 0.60f),
                    FrameNode("engine_rear", "Dudukan Mesin Belakang", 0.52f, 0.65f),
                    FrameNode("swingarm_pivot", "Poros Lengan Ayun", 0.62f, 0.65f),
                    FrameNode("rear_hub", "As Roda Belakang", 0.84f, 0.75f),
                    FrameNode("seat_front", "Dudukan Jok Depan", 0.56f, 0.38f), // Flat seat line
                    FrameNode("seat_rear", "Ujung Jok Belakang", 0.74f, 0.38f)  // Flat seat line
                )
            }
            else -> { // Custom
                _wheelbaseMm.value = 1300f
                _designName.value = "Desain Sasis Kustom Baru"
                listOf(
                    FrameNode("front_hub", "As Roda Depan", 0.16f, 0.75f),
                    FrameNode("steering_head", "Komstir (Steering Head)", 0.35f, 0.30f),
                    FrameNode("backbone_joint", "Pangkal Backbone", 0.46f, 0.32f),
                    FrameNode("engine_front", "Dudukan Mesin Depan", 0.38f, 0.58f),
                    FrameNode("engine_rear", "Dudukan Mesin Belakang", 0.52f, 0.64f),
                    FrameNode("swingarm_pivot", "Poros Lengan Ayun", 0.62f, 0.64f),
                    FrameNode("rear_hub", "As Roda Belakang", 0.84f, 0.75f),
                    FrameNode("seat_front", "Dudukan Jok Depan", 0.58f, 0.40f),
                    FrameNode("seat_rear", "Ujung Jok Belakang", 0.74f, 0.40f)
                )
            }
        }
        _currentNodes.value = metrics
        _aiAnalysis.value = null
        _activeDesignId.value = null
    }

    fun loadDesign(design: FrameDesign) {
        _activeDesignId.value = design.id
        _designName.value = design.name
        _motorType.value = design.motorType
        _wheelbaseMm.value = design.wheelbaseMm
        _materialType.value = design.materialType
        _tubeOD.value = design.tubeOuterDiameterMm
        _tubeThickness.value = design.tubeThicknessMm
        _currentNodes.value = FrameNode.jsonStringToList(design.nodesJson)
        _aiAnalysis.value = design.aiResponse
    }

    fun saveCurrentDesign() {
        viewModelScope.launch {
            val metrics = getCalculatedMetrics()
            val nodesString = FrameNode.listToJsonString(_currentNodes.value)
            
            val design = FrameDesign(
                id = _activeDesignId.value ?: 0L,
                name = _designName.value,
                motorType = _motorType.value,
                wheelbaseMm = _wheelbaseMm.value,
                rakeAngle = metrics.rakeAngle,
                trailMm = metrics.trailMm,
                seatHeightMm = metrics.seatHeightMm,
                materialType = _materialType.value,
                tubeOuterDiameterMm = _tubeOD.value,
                tubeThicknessMm = _tubeThickness.value,
                calculatedWeightKg = metrics.frameWeightKg,
                nodesJson = nodesString,
                aiResponse = _aiAnalysis.value
            )

            val insertedId = repository.insertDesign(design)
            _activeDesignId.value = insertedId
        }
    }

    fun deleteDesign(design: FrameDesign) {
        viewModelScope.launch {
            repository.deleteDesign(design)
            if (_activeDesignId.value == design.id) {
                _activeDesignId.value = null
            }
        }
    }

    fun runAiAnalysis() {
        val metrics = getCalculatedMetrics()
        val nodes = _currentNodes.value
        
        // Build a readable summary of nodes relations for Gemini
        val nodesSummary = buildString {
            nodes.forEach { node ->
                append("- ${node.label} (${node.id}): Posisi Relatif X=${String.format("%.2f", node.x)}, Y=${String.format("%.2f", node.y)}\n")
            }
        }

        _isLoadingAi.value = true
        _aiAnalysis.value = "Menganalisis geometri dan kekuatan struktur sasis dengan Gemini AI..."

        viewModelScope.launch {
            val response = GeminiClient.analyzeFrame(
                motorType = _motorType.value,
                wheelbaseMm = _wheelbaseMm.value,
                rakeAngle = metrics.rakeAngle,
                trailMm = metrics.trailMm,
                seatHeightMm = metrics.seatHeightMm,
                materialType = _materialType.value,
                tubeOD = _tubeOD.value,
                thickness = _tubeThickness.value,
                weightKg = metrics.frameWeightKg,
                nodesSummary = nodesSummary
            )
            _aiAnalysis.value = response
            _isLoadingAi.value = false
            
            // Auto save AI report if already saved
            if (_activeDesignId.value != null) {
                saveCurrentDesign()
            }
        }
    }
}

// Helper data classes
data class FrameSegment(
    val id: String,
    val fromId: String,
    val toId: String,
    val label: String,
    val isStructural: Boolean
)

data class FrameMetrics(
    val rakeAngle: Float = 0f,
    val trailMm: Float = 0f,
    val seatHeightMm: Float = 0f,
    val frameWeightKg: Float = 0f,
    val scale: Float = 1f
)
