package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val GeometricBalanceColorScheme = lightColorScheme(
    primary = GeoPrimary,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    secondary = GeoSecondary,
    onSecondary = GeoTextDeepAccent,
    tertiary = GeoTertiary,
    background = GeoBackground,
    onBackground = GeoTextDark,
    surface = GeoSurface,
    onSurface = GeoTextDark,
    surfaceVariant = GeoSurfaceActive,
    onSurfaceVariant = GeoTextDeepAccent,
    outline = GeoBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false, // Force Geometric Balance light mode aesthetic as requested by the theme layout
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GeometricBalanceColorScheme,
        typography = Typography,
        content = content
    )
}

