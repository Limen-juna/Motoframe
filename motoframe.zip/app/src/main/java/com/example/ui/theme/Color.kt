package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Geometric Balance MD3 Light Purple Scheme Colors
val GeoBackground = Color(0xFFFEF7FF)        // Softest purple background
val GeoTextDark = Color(0xFF1D1B20)          // Charcoal MD3 text
val GeoPrimary = Color(0xFF6750A4)           // Majestic primary deep purple
val GeoSecondary = Color(0xFFD0BCFF)         // Bright lavender
val GeoTertiary = Color(0xFF49454F)          // Medium slate text / secondary outline
val GeoSurface = Color(0xFFF3EDF7)           // Main container surface light purple
val GeoSurfaceActive = Color(0xFFE8DEF8)     // Active tab/chip background
val GeoTextDeepAccent = Color(0xFF21005D)    // Deep indigo text accent
val GeoBorder = Color(0xFFCAC4D0)            // Soft neutral border

// Keep legacy values if referenced anywhere
val NeonCyan = Color(0xFF6750A4)
val SafetyOrange = Color(0xFF21005D)
val SteelGrey = Color(0xFF49454F)
val GridBlue = Color(0xFFCAC4D0)

