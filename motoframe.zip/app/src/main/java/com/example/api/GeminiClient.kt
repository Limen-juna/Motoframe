package com.example.api

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiClient {
    private const val TAG = "GeminiClient"
    private const val MODEL = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun analyzeFrame(
        motorType: String,
        wheelbaseMm: Float,
        rakeAngle: Float,
        trailMm: Float,
        seatHeightMm: Float,
        materialType: String,
        tubeOD: Float,
        thickness: Float,
        weightKg: Float,
        nodesSummary: String
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "Kunci API Gemini tidak ditemukan atau masih berupa placeholder. Silakan tambahkan kunci API Anda di panel Secrets AI Studio agar analisis AI bisa berjalan."
        }

        val prompt = """
            Anda adalah seorang insinyur sasis sepeda motor profesional berpengalaman (Professional Motorcycle Frame Designer & Chassis Engineer).
            Tolong berikan analisis teknis mendalam dan tinjauan desain sasis sepeda motor (Frame Design Review) dalam BAHASA INDONESIA untuk spesifikasi berikut:
            
            - Kategori Motor: $motorType
            - Jarak Sumbu Roda (Wheelbase): $wheelbaseMm mm
            - Sudut Rake (Steering Head Rake Angle): $rakeAngle derajat (derajat terhadap vertikal)
            - Jarak Trail: $trailMm mm
            - Tinggi Jok (Seat Height): $seatHeightMm mm
            - Bahan Rangka: $materialType
            - Spesifikasi Pipa: Diameter Luar $tubeOD mm, Ketebalan Dinding $thickness mm
            - Estimasi Berat Rangka: $weightKg kg
            - Hubungan Geometri Node Penting:
            $nodesSummary

            Mohon evaluasi desain ini dalam format Laporan Teknik yang terstruktur rapi dengan Markdown:
            
            1. **Evaluasi Geometri & Karakteristik Pengendalian (Geometry & Handling)**:
               - Bahas stabilitas berkendara berdasarkan Sudut Rake dan Trail. Apakah sudut kemudi terlalu tegak (lincah tapi kurang stabil pada kecepatan tinggi) atau terlalu rebah (stabil lurus tapi lambat menikung)?
               - Apakah jarak sumbu roda (wheelbase) sesuai untuk jenis motor ini?
               
            2. **Kekuatan Struktur & Pilihan Material (Structural Integrity)**:
               - Evaluasi pilihan material ($materialType) dan ukuran pipa ($tubeOD mm x $thickness mm) terhadap beban statis dan dinamis kategori motor ini.
               - Berikan pendapat tentang estimasi berat rangka ($weightKg kg), apakah terlalu berat atau berpotensi ringkih.
               
            3. **Ergonomi & Pusat Gravitasi (Ergonomics & CG)**:
               - Analisis ergonomi posisi tinggi jok ($seatHeightMm mm) dan letak mesin/poros swingarm.
               
            4. **Rekomendasi & Solusi Fabrikasi (Practical Suggestions)**:
               - Berikan saran konkret, langkah demi langkah, untuk meningkatkan kestabilitas, kekuatan, atau kemudahan pengelasan/fabrikasi sasis ini.
               
            Tulis dengan gaya bahasa profesional, tegas, edukatif, namun mudah dipahami oleh perancang motor kustom. Gunakan bullet points, tabel ringkas jika diperlukan, dan penekanan teks (bold) untuk detail penting.
        """.trimIndent()

        try {
            // Build direct JSON payload
            val partsArr = JSONArray().put(JSONObject().put("text", prompt))
            val contentObj = JSONObject().put("parts", partsArr)
            val contentsArr = JSONArray().put(contentObj)
            
            // Add system instruction for persona safety
            val systemInstruction = JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "Anda adalah asisten perancang sasis motor ahli yang berbicara dalam Bahasa Indonesia resmi dan sopan.")))

            val payload = JSONObject().apply {
                put("contents", contentsArr)
                put("systemInstruction", systemInstruction)
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.4)
                })
            }

            val requestBody = payload.toString().toRequestBody("application/json".toMediaType())
            val url = "$BASE_URL?key=$apiKey"

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errBody = response.body?.string() ?: ""
                    Log.e(TAG, "API call failed with code ${response.code}: $errBody")
                    return@withContext "Gagal menghubungi Gemini API (Error ${response.code}). Pastikan koneksi internet aktif dan kunci API Anda valid."
                }

                val resBody = response.body?.string() ?: return@withContext "Respons kosong diterima dari server."
                val jsonRes = JSONObject(resBody)
                
                // Extract candidates[0].content.parts[0].text
                val candidates = jsonRes.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCand = candidates.getJSONObject(0)
                    val content = firstCand.optJSONObject("content")
                    if (content != null) {
                        val parts = content.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            return@withContext parts.getJSONObject(0).optString("text", "Respons tidak dapat dibaca.")
                        }
                    }
                }
                
                return@withContext "Maaf, tidak berhasil memproses analisis sasis dari Gemini. Respons tidak dikenal: $resBody"
            }

        } catch (e: Exception) {
            Log.e(TAG, "Exception during analyzeFrame", e)
            return@withContext "Terjadi kesalahan jaringan atau sistem: ${e.localizedMessage ?: "Koneksi terputus"}. Silakan coba lagi."
        }
    }
}
