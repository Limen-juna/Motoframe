package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface FrameDesignDao {
    @Query("SELECT * FROM frame_designs ORDER BY timestamp DESC")
    fun getAllDesigns(): Flow<List<FrameDesign>>

    @Query("SELECT * FROM frame_designs WHERE id = :id LIMIT 1")
    suspend fun getDesignById(id: Long): FrameDesign?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDesign(design: FrameDesign): Long

    @Query("DELETE FROM frame_designs WHERE id = :id")
    suspend fun deleteDesignById(id: Long)

    @Delete
    suspend fun deleteDesign(design: FrameDesign)
}
