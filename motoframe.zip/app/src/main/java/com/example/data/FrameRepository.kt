package com.example.data

import kotlinx.coroutines.flow.Flow

class FrameRepository(private val dao: FrameDesignDao) {
    val allDesigns: Flow<List<FrameDesign>> = dao.getAllDesigns()

    suspend fun getDesignById(id: Long): FrameDesign? {
        return dao.getDesignById(id)
    }

    suspend fun insertDesign(design: FrameDesign): Long {
        return dao.insertDesign(design)
    }

    suspend fun deleteDesignById(id: Long) {
        dao.deleteDesignById(id)
    }

    suspend fun deleteDesign(design: FrameDesign) {
        dao.deleteDesign(design)
    }
}
