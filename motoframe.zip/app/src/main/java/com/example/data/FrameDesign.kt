package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import org.json.JSONArray
import org.json.JSONObject

data class FrameNode(
    val id: String,
    val label: String,
    val x: Float, // 0f to 1f relative to canvas width
    val y: Float  // 0f to 1f relative to canvas height
) {
    fun toJsonObject(): JSONObject {
        return JSONObject().apply {
            put("id", id)
            put("label", label)
            put("x", x.toDouble())
            put("y", y.toDouble())
        }
    }

    companion object {
        fun fromJsonObject(obj: JSONObject): FrameNode {
            return FrameNode(
                id = obj.getString("id"),
                label = obj.getString("label"),
                x = obj.optDouble("x", 0.5).toFloat(),
                y = obj.optDouble("y", 0.5).toFloat()
            )
        }

        fun listToJsonString(list: List<FrameNode>): String {
            val arr = JSONArray()
            list.forEach { arr.put(it.toJsonObject()) }
            return arr.toString()
        }

        fun jsonStringToList(json: String): List<FrameNode> {
            val list = mutableListOf<FrameNode>()
            try {
                val arr = JSONArray(json)
                for (i in 0 until arr.length()) {
                    list.add(fromJsonObject(arr.getJSONObject(i)))
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return list
        }
    }
}

@Entity(tableName = "frame_designs")
data class FrameDesign(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val motorType: String, // Underbone, Sport, Chopper, CafeRacer, Custom
    val wheelbaseMm: Float,
    val rakeAngle: Float,
    val trailMm: Float,
    val seatHeightMm: Float,
    val materialType: String, // Steel, Chromoly, Aluminum
    val tubeOuterDiameterMm: Float,
    val tubeThicknessMm: Float,
    val calculatedWeightKg: Float,
    val nodesJson: String, // Serialized List<FrameNode>
    val aiResponse: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)
